
#include "Calculator.h"

int main()
{
    std::cout << "------CALCULATOR------\n";
    Calculator calculator;
    calculator.processInput();

    return 0;
}