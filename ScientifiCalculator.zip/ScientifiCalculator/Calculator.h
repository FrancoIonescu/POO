
#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <iostream>
#include "ExpressionManager.h"

class Calculator
{
private:

    ExpressionManager expMgr;
    char* userInput;
    double result;
    const std::string name = "Franco Ionescu";
    static std::string classGroup;

public:

    Calculator();
    Calculator(const char* _userInput, double _result, std::string _name);
    Calculator(const Calculator& calc);
    ~Calculator();

    Calculator& operator=(const Calculator& calc);

    friend std::ostream& operator<<(std::ostream& os, Calculator calc);
    friend std::istream& operator>>(std::istream& is, Calculator& calc);

    void setUserInput(const char* _userInput);
    void setResult(double _result);
    static void setClassGroup(std::string _classGroup);
    std::string getName();
    static std::string getClassGroup();
    char* getUserInput();
    double getResult();
    void processInput();

};

#endif
